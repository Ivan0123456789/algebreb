from algebreb.util.numeros import decimales_aleatorios

decimales1 = decimales_aleatorios(-1, 1, 15)
print(decimales1)

decimales2 = decimales_aleatorios(1, 7, 10)
print(decimales2)