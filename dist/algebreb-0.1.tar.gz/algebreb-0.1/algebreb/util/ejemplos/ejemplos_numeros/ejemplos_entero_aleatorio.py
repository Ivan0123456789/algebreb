from algebreb.util.numeros import entero_aleatorio

entero1 = entero_aleatorio(-100, 100)
print(entero1)

entero2 = entero_aleatorio(1, 10)
print(entero2)

entero3 = entero_aleatorio(-10, 10, 0)
print(entero3)

entero4 = entero_aleatorio(1, 3, 2)
print(entero4)