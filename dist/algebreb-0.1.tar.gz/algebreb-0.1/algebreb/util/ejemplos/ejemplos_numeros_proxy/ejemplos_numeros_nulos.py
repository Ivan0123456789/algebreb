from algebreb.util.numeros_proxy import numeros_nulos

nulos = numeros_nulos(10)
print(nulos)