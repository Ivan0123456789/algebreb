from algebreb.util.numeros import decimal_aleatorio

decimal1 = decimal_aleatorio(-10, 10)
print(decimal1)

decimal2 = decimal_aleatorio(-1, 1, 0.92)
print(decimal2)