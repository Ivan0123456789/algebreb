from algebreb.util.numeros import enteros_aleatorios

enteros1 = enteros_aleatorios(-100, 100, 10)
print(enteros1)

enteros2 = enteros_aleatorios(-7, 9, 10)
print(enteros2)

enteros3 = enteros_aleatorios(-1, 1, 10, 0)
print(enteros3)