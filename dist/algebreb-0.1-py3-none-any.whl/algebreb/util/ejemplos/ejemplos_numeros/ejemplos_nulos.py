from algebreb.util.numeros import nulos

nulos1 = nulos(10)
print(nulos1)